var showValue = function(val){
    document.getElementById('amount').value = parseInt(val);
}